from django.shortcuts import render
from .models import Task

# Create your views here.
def todo(request):
    if request.method=='POST':
        title=request.POST['title']
        description=request.POST['description']
        t1=Task(title=title,description=description)
        t1.save()
        return render(request,'todo.html',{
            "tasks":Task.objects.all()
        })
        
    return render(request,'todo.html')

