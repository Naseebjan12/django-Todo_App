from django.urls import path
from . import views
urlpatterns = [
    path('',views.todo),
    path('delete',views.dlt),
    path('update',views.upd),
]
